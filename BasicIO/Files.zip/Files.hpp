// includes.hpp
#ifndef FILES_HPP
#define FILES_HPP

void writeToFile(string fileName, string text);

void createFile(string fileName);

#endif // FILES_HPP