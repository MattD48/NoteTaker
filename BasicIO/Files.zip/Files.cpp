#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <iostream>

#include "Files.hpp"

using namespace std;

void writeToFile(string fileName, string text) {
    ofstream* myFile;
    myFile->open(fileName);
    myFile->write(text.c_str(), myFile->tellp()); 
    myFile->close();
    delete myFile;
}

void createFile(string fileName){
    ofstream myFile(fileName.c_str()); 
}


