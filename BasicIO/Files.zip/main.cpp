#include "includes.hpp"

using namespace std;

int main () {

    std::string str = "testIO.txt";
    createFile(str);


    return 0; 
}